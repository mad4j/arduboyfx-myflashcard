#pragma once

bool Collision(
  const int x1, const char y1, const byte w1, const byte h1, 
  const int x2, const char y2, const byte w2, const byte h2
);
